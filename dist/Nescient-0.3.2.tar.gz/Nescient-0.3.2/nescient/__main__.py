#!/usr/bin/env python3

from nescient.app import main
    
main()
